# Brainbaby work templates

10 original planning files: nine blank worksheets and one fictional test-case CSV. The CSV is teaching material; no tests were executed. No customer records, generated app, benchmark scores or product credits are included.

Download and edit without an account. AI work is a separate action using your account allowance. These files do not submit bids, send email, execute tests or publish releases. Keep private project details out of public copies.

- test-case-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-test-case-generator
- test-case-example.csv: fictional example; no tests executed. Guide: https://brainbaby.ai/blog/ai-test-case-generator
- bug-report-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-bug-report-generator
- release-notes-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-release-notes-generator
- prd-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-prd-generator
- rfp-response-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-rfp-response-generator
- monthly-client-report-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/monthly-client-report-template
- discovery-call-proposal-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-discovery-call-to-proposal
- customer-case-study-evidence-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/ai-case-study-generator
- meeting-action-items-worksheet.md: blank worksheet. Guide: https://brainbaby.ai/blog/meeting-notes-to-action-items

## License

Copyright 2026 Brainbaby. These 10 original planning files are licensed under Creative Commons Attribution 4.0 International: https://creativecommons.org/licenses/by/4.0/

Suggested credit: Adapted from Brainbaby free creative resources, CC BY 4.0. Indicate your changes. Brainbaby trademarks, application source code and user-supplied content are excluded. No endorsement is implied.

Source library: https://github.com/Brainbaby-OS/free-creative-resources
Public resource page: https://brainbaby.ai/tools#free-resources
